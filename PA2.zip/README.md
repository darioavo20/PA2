# PA2
Artificial Intelligence Programming Assignment 2

As per the instructions, the code can be executed through the command line with the following structure:

python PA2.py 'test_file' 'output_type'

As an example:

python PA2.py test1.txt Verbose

Any of the algorithms, as defined in the test files, can play through a game by themselves given a board.
